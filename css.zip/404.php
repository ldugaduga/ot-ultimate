<?php get_header(); ?>
	
	<div id="main-section" class="pageinner">
		<div class="container">
			<div class="row">
                <div class="col-md-8 col-sm-8">
					<div class="jumbotron">
						<h1>404 Error</h1>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-4">
                     <?php get_sidebar(); ?>
				</div>
			</div>
		</div>
	</div>

<?php get_footer(); ?>

